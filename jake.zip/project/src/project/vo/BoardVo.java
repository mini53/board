package project.vo;

public class BoardVo {

}
